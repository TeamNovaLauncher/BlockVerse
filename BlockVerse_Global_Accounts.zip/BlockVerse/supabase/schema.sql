-- BlockVerse: безопасная регистрация и назначение первого Creator.
-- Выполни весь файл в Supabase Dashboard -> SQL Editor -> New query.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Player' check (char_length(display_name) between 1 and 24),
  role text not null default 'player' check (role in ('creator','admin','moderator','player')),
  avatar_color text not null default '#8e7aff',
  created_at timestamptz not null default now()
);

-- Единственная строка-контейнер для атомарного захвата роли Creator.
create table if not exists public.platform_claim (
  singleton boolean primary key default true check (singleton = true),
  creator_user_id uuid unique references auth.users(id) on delete restrict,
  claimed_at timestamptz
);
insert into public.platform_claim(singleton) values (true) on conflict (singleton) do nothing;

alter table public.profiles enable row level security;
alter table public.platform_claim enable row level security;

-- Профили можно читать, чтобы показывать имена и роли в платформе.
drop policy if exists "Profiles are readable" on public.profiles;
create policy "Profiles are readable" on public.profiles for select to authenticated using (true);

-- Пользователь может менять только своё отображаемое имя и цвет. Роль менять нельзя.
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated
using (auth.uid() = id) with check (auth.uid() = id);
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (display_name, avatar_color) on public.profiles to authenticated;

-- Никому из клиентов не выдаём доступ к таблице захвата Creator.
revoke all on public.platform_claim from anon, authenticated;

create or replace function public.handle_new_blockverse_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  chosen_name text;
  claimed_id uuid;
begin
  chosen_name := coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), split_part(coalesce(new.email, 'Player'), '@', 1));
  chosen_name := left(chosen_name, 24);

  insert into public.profiles(id, display_name, role)
  values (new.id, chosen_name, 'player')
  on conflict (id) do nothing;

  -- UPDATE блокирует строку и атомарно позволяет выиграть только одной регистрации.
  update public.platform_claim
     set creator_user_id = new.id, claimed_at = now()
   where singleton = true and creator_user_id is null
   returning creator_user_id into claimed_id;

  if claimed_id = new.id then
    update public.profiles set role = 'creator' where id = new.id;
  end if;
  return new;
end;
$$;

revoke all on function public.handle_new_blockverse_user() from public, anon, authenticated;
drop trigger if exists on_auth_user_created_blockverse on auth.users;
create trigger on_auth_user_created_blockverse
after insert on auth.users
for each row execute procedure public.handle_new_blockverse_user();

-- Если таблица profiles уже существовала и в ней есть пользователи до установки триггера,
-- они НЕ становятся Creator автоматически. Creator получает первый новый auth.users.
