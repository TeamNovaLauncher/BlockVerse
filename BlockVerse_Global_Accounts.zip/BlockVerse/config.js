// Вставь сюда URL и anon/public key своего Supabase-проекта.
// Никогда не помещай сюда service_role key или пароль базы данных.
export const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_PUBLIC_KEY';
