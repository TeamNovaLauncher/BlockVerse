import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getFirestore, doc, runTransaction, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const $ = (id) => document.getElementById(id);
const message = (text) => $("message").textContent = text;

$("register").addEventListener("click", async () => {
  const email = $("email").value.trim();
  const password = $("password").value;
  const username = $("username").value.trim();
  if (!username) return message("Введи имя игрока.");
  try {
    message("Создаём аккаунт…");
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: username });
    const userRef = doc(db, "users", cred.user.uid);
    const ownerRef = doc(db, "system", "owner");
    const role = await runTransaction(db, async (tx) => {
      const owner = await tx.get(ownerRef);
      const assignedRole = owner.exists() ? "player" : "creator";
      if (!owner.exists()) {
        tx.set(ownerRef, { uid: cred.user.uid, createdAt: serverTimestamp() });
      }
      tx.set(userRef, {
        uid: cred.user.uid, username, email,
        role: assignedRole, createdAt: serverTimestamp()
      });
      return assignedRole;
    });
    message(role === "creator" ? "Аккаунт создан. Ты Creator!" : "Аккаунт создан!");
  } catch (e) { message("Ошибка: " + e.message); }
});

$("login").addEventListener("click", async () => {
  try {
    message("Входим…");
    await signInWithEmailAndPassword(auth, $("email").value.trim(), $("password").value);
  } catch (e) { message("Ошибка: " + e.message); }
});

$("logout").addEventListener("click", async () => {
  try { await signOut(auth); } catch (e) { message("Ошибка: " + e.message); }
});

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    $("authPanel").hidden = false;
    $("accountPanel").hidden = true;
    return;
  }
  $("authPanel").hidden = true;
  $("accountPanel").hidden = false;
  try {
    const { getDoc } = await import("https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js");
    const snap = await getDoc(doc(db, "users", user.uid));
    const data = snap.exists() ? snap.data() : {};
    $("accountInfo").textContent =
      `${data.username || user.displayName || "Игрок"} • ${user.email || ""} • Роль: ${data.role || "профиль не создан"}`;
  } catch (e) {
    $("accountInfo").textContent = "Вход выполнен, но профиль не прочитан: " + e.message;
  }
});
