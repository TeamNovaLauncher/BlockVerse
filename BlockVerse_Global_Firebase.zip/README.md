# BlockVerse — Global Firebase Accounts

This is the Firebase-connected web starter for BlockVerse global accounts.

## Included
- `index.html` — registration/login/profile page
- `app.js` — Firebase Authentication + Firestore profile logic
- `firebase-config.js` — your Firebase web app configuration
- `firestore.rules` — Firestore security rules

## Setup
1. In Firebase Console, Authentication → Sign-in method → enable Email/Password.
2. In Firestore Database → Rules, publish the contents of `firestore.rules`.
3. Upload all four files to the root of your GitHub repository (not inside the ZIP).
4. Enable GitHub Pages for the repository, or deploy the files to Firebase Hosting.
5. Open the deployed HTTPS site and create an account.

## Creator role
The first account that successfully creates the `/system/owner` record in the Firestore transaction receives `creator`. Later accounts receive `player`. This means the first Firebase Authentication account is not automatically guaranteed to be Creator if another registration claims the owner record first.

## Important
This is a working account-system starter, not a complete Roblox-like platform. It does not yet contain 3D games, chat, friends, game publishing, or multiplayer. Never upload Firebase Admin SDK service-account JSON or private server credentials.
